from utils import sha

def validate(initial,repaired,initial_public,repaired_public,hidden):
    checks={
      'changed':sha(initial)!=sha(repaired),
      'initial_executed':initial_public.get('status')=='EXECUTED_INDEPENDENT',
      'observed_failure':initial_public.get('score',1)<1,
      'repair_executed':repaired_public.get('status')=='EXECUTED_INDEPENDENT',
      'repair_public_pass':repaired_public.get('score')==1,
      'hidden_executed':hidden.get('status')=='EXECUTED_INDEPENDENT',
      'hidden_pass':hidden.get('score')==1,
    }
    return {'decision':'PASS' if all(checks.values()) else 'FAIL','checks':checks}
