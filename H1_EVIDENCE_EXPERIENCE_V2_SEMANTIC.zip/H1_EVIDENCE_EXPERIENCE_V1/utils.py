from __future__ import annotations
import ast, csv, hashlib, json, os, re, shutil, subprocess, sys, tempfile, time, urllib.request, urllib.error, uuid
from pathlib import Path
from datetime import datetime, timezone
from settings import *

def sha(x): return hashlib.sha256(x.encode('utf-8')).hexdigest()


def now(): return datetime.now(timezone.utc).isoformat()


def write_json(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,indent=2,ensure_ascii=False,default=str),encoding='utf-8')


def append_jsonl(p,obj):
    with p.open('a',encoding='utf-8') as f: f.write(json.dumps(obj,ensure_ascii=False,default=str)+'\n')


def extract_code(text):
    blocks=re.findall(r'```(?:python)?\s*\n(.*?)```',text,re.I|re.S)
    code=(blocks[0] if blocks else text).strip()
    if len(code)>12000: raise ValueError('SOLVER_INVALID_OUTPUT: excessive code')
    try: ast.parse(code)
    except (SyntaxError,ValueError) as e: raise ValueError('SOLVER_INVALID_OUTPUT: syntax') from e
    return code

