from __future__ import annotations
import ast, csv, hashlib, json, os, re, shutil, subprocess, sys, tempfile, time, urllib.request, urllib.error, uuid
from pathlib import Path
from datetime import datetime, timezone
from settings import *
from model_client import llm

def induce(task,bad,good,feedback,seed,trace):
    prompt=('You extract a generalizable procedure from an observed repair. Do NOT repeat source task specifics. '
            'Return ONLY JSON object with string keys precondition, action, postcondition, warning. '
            'ACTION must explicitly describe the corrective mechanism (e.g. empty-input guard or preserving first-occurrence order), not merely ordinary processing. Do not claim transfer was proven.\nTask:\n'+task['prompt']+'\nFailed code:\n'+bad+
            '\nVerified repaired code:\n'+good+'\nPublic feedback:\n'+feedback)
    response=llm([{'role':'user','content':prompt}],seed,trace,'induce:'+task['id'])
    match=re.search(r'\{.*\}',response,re.S)
    if not match: raise ValueError('INVALID_EXPERIENCE_JSON')
    obj=json.loads(match.group())
    if not all(isinstance(obj.get(k),str) and 5<=len(obj[k].strip())<=800 for k in ('precondition','action','postcondition','warning')):
        raise ValueError('INVALID_EXPERIENCE_SCHEMA')
    return {k:obj[k].strip() for k in ('precondition','action','postcondition','warning')}

