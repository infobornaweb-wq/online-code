import unittest
from unittest.mock import patch
from pathlib import Path
from rule_validator import validate_rule

class SemanticTests(unittest.TestCase):
 def setUp(self):
  self.task={'id':'SRC_ZERO','family':'zero_divisor','fn':'safe_average'}
  self.bad='def safe_average(nums):\n    return sum(nums)/len(nums)\n'
  self.good='def safe_average(nums):\n    if not nums: return 0.0\n    return sum(nums)/len(nums)\n'
  self.candidate={'source_task':'SRC_ZERO','family':'zero_divisor','procedure':{'action':'Check empty input and return zero before division'}}
 def evaluator(self,code,task,tests,artifacts,kind):
  if 'semantic_ablation_initial' in kind: return {'status':'EXECUTED_INDEPENDENT','passed':2,'total':3,'artifact':'before.json'}
  return {'status':'EXECUTED_INDEPENDENT','passed':3,'total':3,'artifact':'after.json'}
 @patch('rule_validator.evaluate')
 def test_valid_scoped(self,m):
  m.side_effect=self.evaluator
  x=validate_rule(self.candidate,self.task,self.bad,self.good,Path('.'))
  self.assertEqual(x['decision'],'PASS')
  self.assertEqual(x['scope'],'SOURCE_FAMILY_LOCAL_MECHANISM_ONLY')
  self.assertEqual(m.call_count,2)
 @patch('rule_validator.evaluate')
 def test_claim_not_grounded(self,m):
  c={**self.candidate,'procedure':{'action':'Always sort numbers before calculation'}}
  self.assertEqual(validate_rule(c,self.task,self.bad,self.good,Path('.'))['decision'],'UNRESOLVED')
  m.assert_not_called()
 @patch('rule_validator.evaluate')
 def test_counterfactual_no_failure(self,m):
  m.return_value={'status':'EXECUTED_INDEPENDENT','passed':3,'total':3}
  self.assertEqual(validate_rule(self.candidate,self.task,self.bad,self.good,Path('.'))['decision'],'FAIL')
 @patch('rule_validator.evaluate')
 def test_infra_unresolved(self,m):
  m.return_value={'status':'INFRA_ERROR','passed':0,'total':3}
  self.assertEqual(validate_rule(self.candidate,self.task,self.bad,self.good,Path('.'))['decision'],'UNRESOLVED')
 def test_unsupported_family(self):
  c={**self.candidate,'family':'unknown'}
  self.assertEqual(validate_rule(c,self.task,self.bad,self.good,Path('.'))['decision'],'UNRESOLVED')
if __name__=='__main__':unittest.main()
