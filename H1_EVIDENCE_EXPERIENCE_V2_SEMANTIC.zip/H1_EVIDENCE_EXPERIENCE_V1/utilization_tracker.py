def observe(experience,code):
    return {'retrieved':experience is not None,'exposed':experience is not None,
            'utilization':'UNRESOLVED' if experience is not None else 'NOT_EXPOSED',
            'note':'Behavioral alignment alone cannot prove causal use of memory'}
