"""Conservative, executable, *task-local* semantic audit.

PASS means a specified mechanism has structural support and independent
counterfactual probes for THIS source family. It does not certify arbitrary
natural-language generalizations or prove transfer.
"""
import ast
import re
from outcome_evaluator import evaluate
from utils import sha

# Independent probes are neither source public nor source hidden tests.
# These fixtures are predefined, not generated from model responses.
PROBES = {
 'empty_tokens': [('first_token("    blue  green ")','blue'), ('first_token("\t\n")',''), ('first_token("  one  ")','one')],
 'zero_divisor': [('safe_average([])',0.0),('safe_average([7, 9, 11])',9.0),('safe_average([-9, 3])',-3.0)],
 'dedup_order': [('unique_ordered([4, 2, 4, 1, 2])',[4,2,1]),('unique_ordered(["x","y","x"])',["x","y"]),('unique_ordered([9])',[9])]
}
# Minimal, preregistered language anchors: ambiguous or contradictory claims
# cannot pass solely because code tests pass.
ANCHORS = {
 'empty_tokens': (('empty','blank','whitespace','no token','no tokens'),('check','guard','handle','return','avoid','prevent')),
 'zero_divisor': (('empty','zero','division','divisor','length'),('check','guard','handle','return','avoid','prevent')),
 'dedup_order': (('duplicate','duplicates','dedup','unique','repeated'),('order','first','preserv','retain','stable')),
}

def _has_guard(code, family):
    try: tree=ast.parse(code)
    except (SyntaxError,ValueError): return False
    fn=next((n for n in tree.body if isinstance(n,ast.FunctionDef)),None)
    if fn is None: return False
    if family in ('empty_tokens','zero_divisor'):
        # An explicit early conditional branch is needed, not just a passing oracle.
        return any(isinstance(n,ast.If) and any(isinstance(x,ast.Return) for x in n.body)
                   for n in ast.walk(fn))
    if family=='dedup_order':
        # A stable first-occurrence dedup operation must be visible in code.
        return any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in ('dict','set')
                   for n in ast.walk(fn)) or ('dict.fromkeys' in code)
    return False

def validate_rule(candidate, source=None, initial=None, repaired=None, artifact_dir=None):
    family=candidate.get('family') if isinstance(candidate,dict) else None
    if source is None or initial is None or repaired is None or artifact_dir is None:
        return {'decision':'UNRESOLVED','semantic_rule_verified':False,'reason':'Executable evidence inputs not supplied'}
    if family not in PROBES or source.get('family')!=family or source.get('id')!=candidate.get('source_task'):
        return {'decision':'UNRESOLVED','semantic_rule_verified':False,'reason':'No preregistered oracle for this task family'}
    p=candidate.get('procedure') or {}
    action=p.get('action','')
    if not isinstance(action,str):
        return {'decision':'FAIL','semantic_rule_verified':False,'reason':'Action is not a string'}
    low=action.lower()
    anchors=ANCHORS[family]
    claim_aligned=all(any(re.search(r'\b'+re.escape(word),low) for word in group) for group in anchors)
    if re.search(r'\b(?:never|do not|dont|avoid)\s+(?:check|guard|preserve|retain)\b',low):
        claim_aligned=False
    # Explicit contradictions are disqualifying. The restricted phrase matcher
    # is not a general entailment checker; unfamiliar wording remains unresolved.
    if not claim_aligned:
        return {'decision':'UNRESOLVED','semantic_rule_verified':False,'reason':'Rule wording not independently aligned with the tested mechanism',
                'checks':{'claim_aligned':False}}
    structure=_has_guard(repaired,family)
    if not structure:
        return {'decision':'UNRESOLVED','semantic_rule_verified':False,'reason':'No recognizable implementation of claimed mechanism',
                'checks':{'claim_aligned':True,'mechanism_structure':False}}
    tests=PROBES[family]
    before=evaluate(initial,source,tests,artifact_dir,'semantic_ablation_initial')
    after=evaluate(repaired,source,tests,artifact_dir,'semantic_independent_repair')
    results={'claim_aligned':claim_aligned,'mechanism_structure':structure,
             'before_executed':before.get('status')=='EXECUTED_INDEPENDENT',
             'after_executed':after.get('status')=='EXECUTED_INDEPENDENT',
             'before_failed_probe':before.get('passed',len(tests))<len(tests),
             'after_passed_all':after.get('passed')==len(tests)}
    # The original code is a counterfactual baseline, not a surgical mutation.
    # When more than one semantic edit exists, causation of a specific edit
    # remains unresolved. Require a single top-level changed statement span.
    try:
        old=ast.parse(initial).body[0].body
        new=ast.parse(repaired).body[0].body
        old_dump=[ast.dump(n,include_attributes=False) for n in old]
        new_dump=[ast.dump(n,include_attributes=False) for n in new]
        import difflib
        changes=[x for x in difflib.SequenceMatcher(None,old_dump,new_dump,autojunk=False).get_opcodes() if x[0]!='equal']
        results['single_change_region']=len(changes)==1
    except (SyntaxError,IndexError,AttributeError):
        results['single_change_region']=False
    decision='PASS' if all(results.values()) else ('UNRESOLVED' if not results['before_executed'] or not results['after_executed'] or not results['single_change_region'] else 'FAIL')
    return {'decision':decision,'semantic_rule_verified':decision=='PASS',
            'scope':'SOURCE_FAMILY_LOCAL_MECHANISM_ONLY',
            'method':'structural_match_plus_original_baseline_ablation_plus_independent_probes',
            'checks':results,'initial_code_sha256':sha(initial),'repaired_code_sha256':sha(repaired),
            'probe_count':len(tests),'before':{k:before.get(k) for k in ('status','passed','total','artifact')},
            'after':{k:after.get(k) for k in ('status','passed','total','artifact')},
            'limitation':'Original-vs-repaired comparison is not a surgical edit ablation; task-local evidence does not prove universal rule or causal transfer.'}
