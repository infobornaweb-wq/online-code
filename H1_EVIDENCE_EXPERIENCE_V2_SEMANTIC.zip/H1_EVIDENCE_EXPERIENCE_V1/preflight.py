from __future__ import annotations
import ast, csv, hashlib, json, os, re, shutil, subprocess, sys, tempfile, time, urllib.request, urllib.error, uuid
from pathlib import Path
from datetime import datetime, timezone
from settings import *
from utils import extract_code, now
from sandbox_evaluator import classify_docker_exit
from solver import public_feedback

def preflight():
    x={'time':now(),'mode':MODE,'python':sys.version.split()[0],'ollama_url':OLLAMA_URL,'model':MODEL,'docker_image':DOCKER_IMAGE}
    if MODE=='OFFLINE': x['status']='OFFLINE_NO_EXTERNAL_EXECUTION';return x
    if MODE not in ('AUTO','LIVE'): x['status']='INVALID_MODE';return x
    try:
        with urllib.request.urlopen(OLLAMA_URL.rstrip('/')+'/api/tags',timeout=8) as r: data=json.load(r)
        x['model_available']=any(z.get('name')==MODEL for z in data.get('models',[]))
    except Exception as e: x['model_available']=False;x['ollama_error']=str(e)
    try:
        p=subprocess.run(['docker','image','inspect',DOCKER_IMAGE],capture_output=True,timeout=10)
        x['docker_image_present']=p.returncode==0
        if p.returncode==0:
            try: x['docker_image_id']=json.loads(p.stdout)[0]['Id']
            except Exception: pass
    except Exception as e: x['docker_image_present']=False;x['docker_error']=str(e)
    x['status']='READY' if x['model_available'] and x['docker_image_present'] else 'BLOCKED'
    return x


def selftest():
    checks={}
    def check(name,cond): checks[name]=bool(cond)
    check('source_transfer_disjoint',not ({x['id'] for x in TASKS if x['split']=='source'} & {x['id'] for x in TASKS if x['split']=='transfer'}))
    check('unique_task_ids',len({x['id'] for x in TASKS})==len(TASKS))
    check('every_task_has_tests',all(x['public'] and x['hidden'] for x in TASKS))
    check('valid_splits',all(x['split'] in ('source','transfer') for x in TASKS))
    check('three_source_families',len({x['family'] for x in TASKS if x['split']=='source'})==3)
    check('transfer_has_source_family',all(x['family'] in {s['family'] for s in TASKS if s['split']=='source'} for x in TASKS if x['split']=='transfer'))
    check('source_test_no_exact_overlap',all(not ({p[0] for p in t['public']} & {h[0] for h in t['hidden']}) for t in TASKS))
    check('runner_result_schema', isinstance({'checks':[True],'details':[]},dict))
    check('code_parse',extract_code('```python\ndef f(x):\n return x\n```').startswith('def f'))
    check('bad_code_rejected',_raises(lambda:extract_code('def f(:')))
    check('mode_valid',MODE in ('AUTO','LIVE','OFFLINE'))
    check('classification_oom_unresolved',classify_docker_exit(137,'',1,2)=='UNRESOLVED')
    check('classification_daemon_infra',classify_docker_exit(125,'',1,2)=='INFRA_ERROR')
    check('classification_nonzero_unresolved',classify_docker_exit(1,'',1,2)=='UNRESOLVED')
    check('public_feedback_does_not_require_hidden', 'failures' in public_feedback({'passed':0,'total':1,'details':[{'expression':'f(0)','passed':False,'actual_repr':'1'}]}))
    check('sham_never_from_matching_family',all(any(s['family']!=t['family'] for s in TASKS if s['split']=='source') for t in TASKS if t['split']=='transfer'))
    return checks


def _raises(fn):
    try: fn();return False
    except Exception:return True

