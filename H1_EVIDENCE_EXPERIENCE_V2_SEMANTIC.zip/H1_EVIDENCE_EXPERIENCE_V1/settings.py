from __future__ import annotations
import ast, csv, hashlib, json, os, re, shutil, subprocess, sys, tempfile, time, urllib.request, urllib.error, uuid
from pathlib import Path
from datetime import datetime, timezone
MODE = 'LIVE'  # AUTO attempts LIVE when Ollama and Docker are ready; OFFLINE explicitly disables it
OLLAMA_URL = 'http://172.19.3.91:11434'
MODEL = 'llama3.1:8b'
DOCKER_IMAGE = 'python:3.11-slim'  # MUST already be pulled; no network pull
OUTPUT_ROOT = Path(__file__).resolve().parent / 'H1_RESULTS'
SEEDS = [42, 101]
MAX_REPAIR_ROUNDS = 3
MODEL_TIMEOUT_S = 150
SOLVER_TIMEOUT_S = 12
DOCKER_CALL_TIMEOUT_S = 90
MAX_OUTPUT_BYTES = 16000
EXPERIMENT_LABEL = 'DEVELOPMENT_ONLY_NOT_CONFIRMATORY'
SOURCE_MODE = 'SEEDED_DEFECT'  # SEEDED_DEFECT or NATURAL_REPAIR; NEVER conflate
MAX_SOURCE_TASKS = 3
MAX_TRANSFER_TASKS = 6
SEEDS = [42]  # pilot only
# Use MODE='LIVE' for external execution; OFFLINE only tests internal contracts
# Do not tune these settings based on transfer-test outcomes.
ARM_ORDER = ('NONE', 'VALID', 'SHAM')

# Training tasks and transfer tasks are separate. Tests are withheld from the LLM.
# Source tasks have public tests for feedback and independent hidden tests for source admission.
TASKS = [
 dict(id='SRC_EMPTY', split='source', family='empty_tokens', fn='first_token',
      prompt='Implement first_token(text: str) -> str. Return the first whitespace-delimited token, or an empty string for empty/whitespace-only input.',
      public=[('first_token("red blue")','red'),('first_token("")','')],
      hidden=[('first_token("   ")',''),('first_token("z")','z')]),
 dict(id='SRC_ZERO', split='source', family='zero_divisor', fn='safe_average',
      prompt='Implement safe_average(nums: list[float]) -> float. Return 0.0 for an empty list, otherwise arithmetic mean.',
      public=[('safe_average([2,4])',3.0),('safe_average([])',0.0)],
      hidden=[('safe_average([-2,2])',0.0),('safe_average([5])',5.0)]),
 dict(id='SRC_DUP', split='source', family='dedup_order', fn='unique_ordered',
      prompt='Implement unique_ordered(items: list) -> list. Remove duplicates while preserving first occurrence order. Items are hashable.',
      public=[('unique_ordered([1,2,1])',[1,2])],
      hidden=[('unique_ordered([])',[]),('unique_ordered([3,1,3,2,1])',[3,1,2])]),
 dict(id='TR_EMPTY_A',split='transfer',family='empty_tokens',fn='last_token',
      prompt='Implement last_token(text: str) -> str. Return last whitespace-separated token; for empty/whitespace-only input return empty string.',
      public=[('last_token("a b")','b')],hidden=[('last_token("")',''),('last_token(" ")',''),('last_token("a b c")','c')]),
 dict(id='TR_EMPTY_B',split='transfer',family='empty_tokens',fn='word_count',
      prompt='Implement word_count(text: str) -> int. Count whitespace-separated words, including zero for blank text.',
      public=[('word_count("a b")',2)],hidden=[('word_count("")',0),('word_count("   ")',0),('word_count("a  b c")',3)]),
 dict(id='TR_ZERO_A',split='transfer',family='zero_divisor',fn='fraction_positive',
      prompt='Implement fraction_positive(nums: list[float]) -> float. Fraction of numbers greater than zero, returning 0.0 for empty input.',
      public=[('fraction_positive([1,-1])',0.5)],hidden=[('fraction_positive([])',0.0),('fraction_positive([1,2])',1.0)]),
 dict(id='TR_ZERO_B',split='transfer',family='zero_divisor',fn='pass_rate',
      prompt='Implement pass_rate(flags: list[bool]) -> float. Return proportion of True values, or 0.0 for empty input.',
      public=[('pass_rate([True,False])',0.5)],hidden=[('pass_rate([])',0.0),('pass_rate([True,True])',1.0)]),
 dict(id='TR_DUP_A',split='transfer',family='dedup_order',fn='distinct_words',
      prompt='Implement distinct_words(words: list[str]) -> list[str]. Keep only first occurrence of each word, retaining input order.',
      public=[('distinct_words(["a","b","a"])',["a","b"])],hidden=[('distinct_words([])',[]),('distinct_words(["z","a","z","b"])',["z","a","b"])]) ,
 dict(id='TR_DUP_B',split='transfer',family='dedup_order',fn='first_seen_ids',
      prompt='Implement first_seen_ids(ids: list[int]) -> list[int]. Remove repeated IDs, preserving original order.',
      public=[('first_seen_ids([2,1,2])',[2,1])],hidden=[('first_seen_ids([])',[]),('first_seen_ids([5,4,5,3])',[5,4,3])]),
]

# Fix accidental parenthesis typo is caught by selftest, not silently ignored.
