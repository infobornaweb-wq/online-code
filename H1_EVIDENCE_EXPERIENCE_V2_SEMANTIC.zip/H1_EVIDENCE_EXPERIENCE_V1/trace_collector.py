import uuid
from utils import append_jsonl,now,sha
class Trace:
    def __init__(self,path): self.path=path
    def add(self,kind,**payload):
        event={'event_id':'EV_'+uuid.uuid4().hex[:16],'time':now(),'kind':kind,**payload}
        append_jsonl(self.path,event)
        return event
