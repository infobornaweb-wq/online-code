from dataclasses import dataclass, asdict
from typing import Literal
@dataclass(frozen=True)
class EvidenceRef:
    event_id: str
    artifact: str
    sha256: str
@dataclass(frozen=True)
class ExperienceCandidate:
    id: str
    source_task: str
    family: str
    origin_type: Literal['NATURAL_REPAIR','SEEDED_DEFECT_REPAIR']
    procedure: dict
    evidence: dict
    status: str = 'RAW'
@dataclass(frozen=True)
class AuditDecision:
    decision: Literal['PASS','FAIL','UNRESOLVED']
    checks: dict
    reason: str
