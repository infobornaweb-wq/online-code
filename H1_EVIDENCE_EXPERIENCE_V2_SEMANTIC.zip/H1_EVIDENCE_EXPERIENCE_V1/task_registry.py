from settings import TASKS

def source_tasks(): return [x for x in TASKS if x['split']=='source']
def transfer_tasks(): return [x for x in TASKS if x['split']=='transfer']
# A known defective implementation is a controlled engineering fixture, NOT a natural LLM failure.
DEFECTS={
 'SRC_EMPTY': 'def first_token(text: str) -> str:\n    return text.split()[0]\n',
 'SRC_ZERO': 'def safe_average(nums: list[float]) -> float:\n    return sum(nums)/len(nums)\n',
 'SRC_DUP': 'def unique_ordered(items: list) -> list:\n    return list(reversed(list(dict.fromkeys(items))))\n',
}
# Escape decoding is only used to construct deterministic, explicit defect fixtures.
DEFECTS={k:v.replace('\\n','\n') for k,v in DEFECTS.items()}
