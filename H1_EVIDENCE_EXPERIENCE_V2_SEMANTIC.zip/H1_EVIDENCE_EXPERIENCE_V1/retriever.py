def select(memory,task,arm):
    if arm=='NONE':return None
    if arm=='RAW': return next((m for m in memory.raw if m['family']==task['family']),None)
    if arm=='VERIFIED':return next((m for m in memory.verified if m['family']==task['family']),None)
    if arm=='SHAM':return next((m for m in memory.raw if m['family']!=task['family']),None)
    raise ValueError('Unknown arm')
