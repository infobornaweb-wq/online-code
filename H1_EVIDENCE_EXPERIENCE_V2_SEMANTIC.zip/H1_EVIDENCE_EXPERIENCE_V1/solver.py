from __future__ import annotations
import ast, csv, hashlib, json, os, re, shutil, subprocess, sys, tempfile, time, urllib.request, urllib.error, uuid
from pathlib import Path
from datetime import datetime, timezone
from settings import *
from utils import extract_code
from model_client import llm

def public_feedback(result):
    # Only source public-test details; NEVER include hidden oracle or transfer outcomes.
    items=result.get('details') or []
    failures=[{'expression':x['expression'],'observed':x['actual_repr']} for x in items if not x['passed']]
    return json.dumps({'passed':result['passed'],'total':result['total'],'failures':failures},ensure_ascii=False)


def solver(task,seed,trace,experience=None,feedback=None,previous=None):
    system='Write a single Python function. Return only valid Python code. No markdown, no imports requiring pip. Do not read files or use network.'
    user=task['prompt']
    if experience: user+='\n\nRelevant previous experience (may be imperfect; use only if applicable):\n'+experience
    if previous is not None: user+='\n\nYour previous solution:\n'+previous+'\nPublic-test feedback:\n'+feedback+'\nRepair the function.'
    return extract_code(llm([{'role':'system','content':system},{'role':'user','content':user}],seed,trace,'solver:'+task['id']))

