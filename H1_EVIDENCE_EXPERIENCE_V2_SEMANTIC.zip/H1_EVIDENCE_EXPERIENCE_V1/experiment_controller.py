import csv,json,random,uuid,sys,traceback
from pathlib import Path
from datetime import datetime,timezone
from settings import *
from task_registry import source_tasks,transfer_tasks,DEFECTS
from preflight import preflight,selftest
from solver import solver,public_feedback
from curator import induce
from outcome_evaluator import evaluate
from repair_validator import validate
from evidence_auditor import audit
from rule_validator import validate_rule
from memory_store import MemoryStore
from retriever import select
from utilization_tracker import observe
from trace_collector import Trace
from causal_analysis import analyze,ARMS
from utils import sha,write_json

def main():
    OUTPUT_ROOT.mkdir(parents=True,exist_ok=True)
    run=OUTPUT_ROOT/('run_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+uuid.uuid4().hex[:6]);run.mkdir()
    trace=Trace(run/'execution_events.jsonl'); calls=run/'model_calls.jsonl'; artifacts=run/'docker_artifacts'
    store=MemoryStore();rows=[]; source_stats={'attempted':0,'initial_failures':0,'repairs_verified':0,'candidates':0}
    checks=selftest();write_json(run/'selftest.json',checks)
    pf=preflight();write_json(run/'preflight.json',pf)
    manifest={'mode':MODE,'source_mode':SOURCE_MODE,'experiment_label':EXPERIMENT_LABEL,'model':MODEL,'ollama_url':OLLAMA_URL,
              'docker_image':DOCKER_IMAGE,'seeds':SEEDS,'max_repair_rounds':MAX_REPAIR_ROUNDS,'arms':ARMS,
              'task_ids':[x['id'] for x in TASKS],'python':sys.version,'status':'DEVELOPMENT'}
    write_json(run/'manifest.json',manifest)
    print('H1 |',MODE,'|',pf['status'],'|',run,flush=True)
    if not all(checks.values()) or pf['status']!='READY':
        write_json(run/'summary.json',{'status':'NOT_EXECUTED','reason':'SELFTEST_FAILED' if not all(checks.values()) else pf['status']});return
    for task in source_tasks()[:MAX_SOURCE_TASKS]:
      source_stats['attempted']+=1
      try:
        if SOURCE_MODE=='SEEDED_DEFECT':
            first=DEFECTS[task['id']];origin='SEEDED_DEFECT_REPAIR'
        elif SOURCE_MODE=='NATURAL_REPAIR':
            first=solver(task,SEEDS[0],calls);origin='NATURAL_REPAIR'
        else: raise ValueError('UNKNOWN_SOURCE_MODE')
        ini=evaluate(first,task,task['public'],artifacts,'source_initial')
        trace.add('source_initial',task_id=task['id'],origin=origin,code_sha256=sha(first),result=ini)
        if ini.get('status')!='EXECUTED_INDEPENDENT' or ini.get('score',1)>=1: continue
        source_stats['initial_failures']+=1;current=first;feedback=public_feedback(ini);repair=None
        for rd in range(MAX_REPAIR_ROUNDS):
            new=solver(task,SEEDS[0]+rd+1,calls,feedback=feedback,previous=current)
            pub=evaluate(new,task,task['public'],artifacts,'source_repair_'+str(rd))
            trace.add('source_repair',task_id=task['id'],round=rd,code_sha256=sha(new),result=pub)
            if pub['status']!='EXECUTED_INDEPENDENT':break
            if pub['score']==1 and sha(first)!=sha(new): repair=(new,pub,feedback);break
            current=new;feedback=public_feedback(pub)
        if not repair:continue
        good,pub,feedback=repair
        hidden=evaluate(good,task,task['hidden'],artifacts,'source_hidden_final_one_shot')
        trace.add('source_hidden_one_shot',task_id=task['id'],result=hidden)
        vr=validate(first,good,ini,pub,hidden)
        trace.add('repair_validation',task_id=task['id'],result=vr)
        if vr['decision']!='PASS':continue
        source_stats['repairs_verified']+=1
        procedure=induce(task,first,good,feedback,SEEDS[0],calls)
        candidate={'id':'EXP_'+task['id']+'_'+uuid.uuid4().hex[:6],'source_task':task['id'],'family':task['family'],
                   'origin_type':origin,'procedure':procedure,
                   'evidence':{'initial_code_sha256':sha(first),'repaired_code_sha256':sha(good),
                   'initial_public_artifact':ini.get('artifact'),'repaired_public_artifact':pub.get('artifact'),
                   'hidden_artifact':hidden.get('artifact')},'status':'RAW'}
        source_stats['candidates']+=1
        pa=audit(candidate,task,first,good,ini,pub,hidden,vr);ra=validate_rule(candidate,task,first,good,artifacts)
        status=store.add(candidate,pa,ra)
        trace.add('experience_admission',task_id=task['id'],memory_id=candidate['id'],status=status,provenance=pa,rule=ra)
      except Exception as e:
        trace.add('source_error',task_id=task['id'],error_type=type(e).__name__,error=str(e))
    store.save(run)
    # No fake VERIFIED arm. If independent semantic rule validation is unresolved,
    # the confirmatory comparison is not estimable. RAW/SHAM exploratory runs are optional.
    if not store.verified:
        trace.add('transfer_not_reached',reason='NO_INDEPENDENTLY_VERIFIED_EXPERIENCE')
    else:
      for task in transfer_tasks()[:MAX_TRANSFER_TASKS]:
       for seed in SEEDS:
        order=list(ARMS);random.Random(seed+sum(map(ord,task['id']))).shuffle(order)
        for arm in order:
          mem=select(store,task,arm)
          if arm!='NONE' and mem is None:
            row={'task':task['id'],'seed':seed,'arm':arm,'status':'NO_ELIGIBLE_MEMORY'}
          else:
            try:
              exp=json.dumps(mem['procedure'],ensure_ascii=False) if mem else None
              code=solver(task,seed,calls,experience=exp)
              outcome=evaluate(code,task,task['hidden'],artifacts,'transfer_'+arm+'_'+str(seed))
              row={'task':task['id'],'seed':seed,'arm':arm,'memory_id':mem['id'] if mem else None,
                   'code_sha256':sha(code),**outcome,'utilization':observe(mem,code)}
            except Exception as e:row={'task':task['id'],'seed':seed,'arm':arm,'status':'MODEL_OR_PARSE_FAILURE','error':str(e)}
          rows.append(row);trace.add('transfer_arm',row=row)
    with (run/'transfer_rows.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=['task','seed','arm','status','score','passed','total','memory_id','code_sha256','artifact','error'],extrasaction='ignore');w.writeheader();w.writerows(rows)
    paired,stats=analyze(rows);write_json(run/'paired_results.json',paired)
    summary={'status':'LIVE_DEVELOPMENT_PILOT_COMPLETED','source':source_stats,'memory_counts':{'raw':len(store.raw),'verified':len(store.verified),'quarantine':len(store.quarantine),'rejected':len(store.rejected)},
             'transfer':stats,'experiment_label':EXPERIMENT_LABEL,'causal_claim':False,
             'interpretation':'Semantic PASS means narrowly scoped structural and independent probe evidence; transfer is development-only, not causal confirmation.'}
    write_json(run/'summary.json',summary)
    (run/'audit_report.md').write_text('# H1 Pilot Audit\n\n'+json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)
    print('RESULTS:',run,flush=True)
