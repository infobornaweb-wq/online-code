from __future__ import annotations
import ast, csv, hashlib, json, os, re, shutil, subprocess, sys, tempfile, time, urllib.request, urllib.error, uuid
from pathlib import Path
from datetime import datetime, timezone
from settings import *
from utils import sha, now, append_jsonl

def llm(messages, seed, trace, tag):
    payload={'model':MODEL,'messages':messages,'stream':False,'options':{'temperature':0,'seed':seed,'num_predict':1200}}
    request=urllib.request.Request(OLLAMA_URL.rstrip('/')+'/api/chat',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
    started=time.monotonic()
    try:
        with urllib.request.urlopen(request,timeout=MODEL_TIMEOUT_S) as response: raw=response.read(500000)
        obj=json.loads(raw)
        content=obj['message']['content']
        if not isinstance(content,str) or not content.strip(): raise ValueError('empty model content')
        append_jsonl(trace,{'time':now(),'tag':tag,'model':MODEL,'seed':seed,'messages_sha256':sha(json.dumps(messages,sort_keys=True)),'response_sha256':sha(content),'response':content,'latency_s':round(time.monotonic()-started,2),'status':'OK'})
        return content
    except (urllib.error.URLError,TimeoutError,ConnectionError,OSError) as e:
        append_jsonl(trace,{'time':now(),'tag':tag,'status':'MODEL_TRANSPORT_ERROR','error':str(e)})
        raise RuntimeError('MODEL_TRANSPORT_ERROR') from e
    except (KeyError,ValueError,json.JSONDecodeError) as e:
        append_jsonl(trace,{'time':now(),'tag':tag,'status':'MODEL_INVALID_RESPONSE','error':str(e)})
        raise RuntimeError('MODEL_INVALID_RESPONSE') from e

