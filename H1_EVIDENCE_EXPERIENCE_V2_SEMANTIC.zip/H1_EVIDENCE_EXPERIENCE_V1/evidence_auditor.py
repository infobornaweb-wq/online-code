from pathlib import Path
from utils import sha

def audit(candidate,source,initial,repaired,initial_public,repaired_public,hidden,repair_result):
    p=candidate['procedure']; ev=candidate['evidence']
    checks={
      'repair_valid':repair_result['decision']=='PASS',
      'task_match':candidate['source_task']==source['id'],
      'origin_declared':candidate['origin_type'] in ('NATURAL_REPAIR','SEEDED_DEFECT_REPAIR'),
      'initial_hash':ev.get('initial_code_sha256')==sha(initial),
      'repair_hash':ev.get('repaired_code_sha256')==sha(repaired),
      'public_initial_artifact':ev.get('initial_public_artifact')==initial_public.get('artifact'),
      'public_repair_artifact':ev.get('repaired_public_artifact')==repaired_public.get('artifact'),
      'hidden_artifact':ev.get('hidden_artifact')==hidden.get('artifact'),
      'artifacts_exist':all(isinstance(x.get('artifact'),str) and Path(x['artifact']).is_file() for x in (initial_public,repaired_public,hidden)),
      'rule_schema':isinstance(p,dict) and all(isinstance(p.get(k),str) and 5<=len(p[k].strip())<=800 for k in ('precondition','action','postcondition','warning')),
    }
    if not all(checks.values()): return {'decision':'FAIL','checks':checks,'semantic_rule_verified':False}
    return {'decision':'PASS','checks':checks,'semantic_rule_verified':False,'reason':'Provenance verified; rule semantics remain unverified'}
