from utils import write_json
class MemoryStore:
    def __init__(self): self.raw=[];self.verified=[];self.quarantine=[];self.rejected=[]
    def add(self,candidate,audit,rule):
        item={**candidate,'provenance_audit':audit,'rule_audit':rule}
        self.raw.append(item)
        if audit['decision']=='FAIL': self.rejected.append(item); return 'REJECTED'
        if audit['decision']=='PASS' and rule['decision']=='PASS': self.verified.append(item);return 'VERIFIED'
        self.quarantine.append(item);return 'QUARANTINE'
    def save(self,folder):
        for name,items in [('raw',self.raw),('verified',self.verified),('quarantine',self.quarantine),('rejected',self.rejected)]: write_json(folder/(name+'_memory.json'),items)
