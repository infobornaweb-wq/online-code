from sandbox_evaluator import docker_eval

def evaluate(code,task,tests,artifact_dir,kind):
    return docker_eval(code,task,tests,artifact_dir,kind)
