import unittest,tempfile
from pathlib import Path
from repair_validator import validate
from rule_validator import validate_rule
from memory_store import MemoryStore
from retriever import select
from causal_analysis import analyze
from settings import TASKS
from task_registry import DEFECTS
from schemas import ExperienceCandidate
class Tests(unittest.TestCase):
 def test_defects(self):
  for v in DEFECTS.values():compile(v,'defect','exec')
 def test_rule_fails_closed(self):self.assertEqual(validate_rule({})['decision'],'UNRESOLVED')
 def test_memory_quarantine(self):
  s=MemoryStore();c={'id':'x','family':'empty_tokens','procedure':{}}
  self.assertEqual(s.add(c,{'decision':'PASS'},{'decision':'UNRESOLVED'}),'QUARANTINE')
  self.assertEqual(len(s.verified),0)
 def test_memory_reject(self):
  s=MemoryStore();self.assertEqual(s.add({}, {'decision':'FAIL'}, {'decision':'PASS'}),'REJECTED')
 def test_retrieval(self):
  s=MemoryStore();s.raw=[{'family':'empty_tokens','id':'a'},{'family':'zero_divisor','id':'b'}]
  t={'family':'empty_tokens'}
  self.assertIsNone(select(s,t,'NONE'))
  self.assertEqual(select(s,t,'RAW')['id'],'a')
  self.assertEqual(select(s,t,'SHAM')['id'],'b')
  self.assertIsNone(select(s,t,'VERIFIED'))
 def test_no_fabricated_pairs(self):self.assertEqual(analyze([])[1]['complete_pairs'],0)
 def test_repair_rejected(self):
  x={'status':'EXECUTED_INDEPENDENT','score':1}
  self.assertEqual(validate('a','b',x,x,x)['decision'],'FAIL')
 def test_schema(self):self.assertEqual(ExperienceCandidate('x','s','f','SEEDED_DEFECT_REPAIR',{},{}).status,'RAW')
if __name__=='__main__':unittest.main(verbosity=2)
