from statistics import mean
ARMS=('NONE','RAW','VERIFIED','SHAM')
def analyze(rows):
    groups={}
    for r in rows: groups.setdefault((r['task'],r['seed']),{})[r['arm']]=r
    complete=[]
    for (task,seed),g in groups.items():
        if not all(k in g and g[k].get('status')=='EXECUTED_INDEPENDENT' for k in ARMS): continue
        complete.append({'task':task,'seed':seed,**{k.lower():g[k]['score'] for k in ARMS},
                         'verified_minus_none':g['VERIFIED']['score']-g['NONE']['score'],
                         'verified_minus_raw':g['VERIFIED']['score']-g['RAW']['score'],
                         'verified_minus_sham':g['VERIFIED']['score']-g['SHAM']['score']})
    return complete,{'complete_pairs':len(complete),'mean_verified_minus_none':mean(x['verified_minus_none'] for x in complete) if complete else None,
                     'mean_verified_minus_raw':mean(x['verified_minus_raw'] for x in complete) if complete else None,
                     'mean_verified_minus_sham':mean(x['verified_minus_sham'] for x in complete) if complete else None,
                     'confirmatory_transfer_proven':False}
